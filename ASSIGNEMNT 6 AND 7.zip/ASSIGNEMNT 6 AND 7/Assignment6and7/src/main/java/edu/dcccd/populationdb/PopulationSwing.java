package edu.dcccd.populationdb;

import javax.swing.*;
import java.awt.*;

import static edu.dcccd.populationdb.CityPopulationService.SEQUENCE;

public class PopulationSwing extends JFrame {   // The class extends the main panel.

    private final JLabel outputLabel;
    private final JLabel outputField;
    private JTextArea tableData;
    private CityPopulationService service;

    public PopulationSwing() {
        tableData = new JTextArea();
        outputLabel = new JLabel();
        outputField = new JLabel();
    }

    public void start() {
        // Instantiates the Service class.
        service = new CityPopulationService();

        // Set the Font to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Set the margin with a new Insets object with top, bottom, and right of 10, and left of 25.
        // Retrieve the formatted population data by calling the getTable method in the service class with sequence 3 .
        // Set the textarea visible.
        tableData.setFont(new Font(Font.MONOSPACED, Font.BOLD, 24));
        tableData.setMargin(new Insets(10, 25, 10, 10));
        tableData.setText(service.getTable(SEQUENCE.NAME));

        // Create a JPanel to hold all the buttons.
        // This panel will use a GridLayout with 3 rows, 4 columns, and horizontal and vertical gap of 10.
        JPanel buttonPanel = new JPanel(new GridLayout(3,4, 10, 10));

        // Set an empty border with left and right margins of 5.
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

        // Create a button by calling a createButton method with a parameter of 'Sort Ascending'.
        // Call the addActionListener on the button object with an argument of e -> getTable(1).
        // Add the button to the button panel.
        JButton sortAscButton = createButton("Sort Ascending");
        sortAscButton.addActionListener(e -> getTable(SEQUENCE.ASC));
        buttonPanel.add(sortAscButton);

        // Create a button by calling a createButton method with a parameter of 'Sort Descending'.
        // Call the addActionListener on the button object with an argument of e -> getTable(2).
        // Add the button to the button panel.
        JButton sortDscButton = createButton("Sort Descending");
        sortDscButton.addActionListener(e -> getTable(SEQUENCE.DSC));
        buttonPanel.add(sortDscButton);

        // Create a button by calling a createButton method with a parameter of 'Sort by Name'.
        // Call the addActionListener on the button object with an argument of e -> getTable(3).
        // Add the button to the button panel.
        JButton sortNmButton = createButton("Sort by Name");
        sortNmButton.addActionListener(e -> getTable(SEQUENCE.NAME));
        buttonPanel.add(sortNmButton);

        // Create a button by calling a createButton method with a parameter of 'Get Total'.
        // Call the addActionListener on the button object with an argument of e -> getStat(1).
        // Add the button to the button panel.
        JButton sortGetTotalButton = createButton("Get Total");
        sortGetTotalButton.addActionListener(e -> getStat(CityPopulationService.STATISTIC.TOTAL));
        buttonPanel.add(sortGetTotalButton);

        // Create a button by calling a createButton method with a parameter of 'Get Average'.
        // Call the addActionListener on the button object with an argument of e -> getStat(2).
        // Add the button to the button panel.
        JButton sortGetAverageButton = createButton("Get Average");
        sortGetAverageButton.addActionListener(e -> getStat(CityPopulationService.STATISTIC.AVERAGE));
        buttonPanel.add(sortGetAverageButton);

        // Create a button by calling a createButton method with a parameter of 'Get Highest'.
        // Call the addActionListener on the button object with an argument of e -> getStat(3).
        // Add the button to the button panel.
        JButton sortGetHighestButton = createButton("Get Highest");
        sortGetHighestButton.addActionListener(e -> getStat(CityPopulationService.STATISTIC.HIGHEST));
        buttonPanel.add(sortGetHighestButton);

        // Create a button by calling a createButton method with a parameter of 'Get Lowest'.
        // Call the addActionListener on the button object with an argument of e -> getStat(4).
        // Add the button to the button panel.
        JButton sortGetLowestButton = createButton("Get Lowest");
        sortGetLowestButton.addActionListener(e -> getStat(CityPopulationService.STATISTIC.LOWEST));
        buttonPanel.add(sortGetLowestButton);

        // Create a button by calling a createButton method with a parameter of 'Exit'.
        // Call the addActionListener on the button object with an argument of e -> System.exit(0).
        // Add the button to the button panel.
        JButton ExitButton = createButton("Exit");
        ExitButton.addActionListener(e -> System.exit(0));
        buttonPanel.add(ExitButton);

        // Create a main JPanel to collect the components into one container.
        // Set the main panel to use a BorderLayout.
        // Set the main panel size to 500 wide and 500 height.
        JPanel panel = new JPanel(new BorderLayout());
        panel.setSize(new Dimension(500 , 500));

        // Add the population data to the main panel.
        panel.add(tableData, BorderLayout.CENTER);

        // Add a new JButton to the button panel with the test "" (a blank) to push output fields to center.
        buttonPanel.add(new JLabel(""));

        // Set the Font on the outputLabel to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Set the horizontalAlignment to SwingConstants.RIGHT.
        outputLabel.setFont(new Font(Font.MONOSPACED, Font.BOLD, 24));
        outputLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        // Set the Font on the outputField to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Set the horizontalAlignment to SwingConstants.LEFT.
        outputField.setFont(new Font(Font.MONOSPACED, Font.BOLD, 24));
        outputField.setHorizontalAlignment(SwingConstants.LEFT);

        // Add the outputLabel and outputField to the button panel
        buttonPanel.add(outputField);
        buttonPanel.add(outputLabel);

        // Add the button panel to the main panel South region.
        panel.add(buttonPanel , BorderLayout.SOUTH);

        // Set the title of the frame to Population Database
        setTitle("Population Database");

        // Add main panel (this) to
        add(panel);

        // Set frame resizable attribute to false.
        setResizable(false);

        // Call the pack method on the frame.
        pack();

        // Set the frame DefaultCloseOperation attribute to EXIT_ON_CLOSE.
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Set the frame to visible true.
        setVisible(true);
    }

    // Create each button to look the same.
    private JButton createButton(String text) {
        // Create a JButton wth the provided text.
        JButton newButton = new JButton(text);
        // Set the button size to 20 wide and 10 height
        newButton.setSize(20,10);
        // Set the button background text to Blue
        newButton.setBackground(Color.BLUE);
        // Set the button foreground text to White
        newButton.setForeground(Color.WHITE);
        // Set the button border painted to false
        newButton.setBorderPainted(false);
        // Set the button opaque attribute to true.
        newButton.setOpaque(true);
        // Set the button font to new Font attributes SANS_SERIF, BOLD, and size of 16.
        newButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        // Set the button to be visible.
        newButton.setVisible(true);
        // return the button object
        return newButton;
    }

    private void getTable(CityPopulationService.SEQUENCE seq) {
        tableData.setText(service.getTable(seq));
    }

    private void getStat(CityPopulationService.STATISTIC stat) {
        // Fetch the output label.
        outputLabel.setText(service.getStat(stat));

        // Fetch the output field value
        outputField.setText(service.getLabel(stat));
    }

    public static void main(String[] args) {
        new PopulationSwing().start();
    }
}
