package edu.dcccd.populationdb;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import static edu.dcccd.populationdb.CityPopulationService.SEQUENCE;

public class PopulationFX extends Application {
    private final Label outputLabel;
    private final Label outputField;
    private final Label tableData;
    private CityPopulationService service;

    public PopulationFX() {
        tableData = new Label();
        outputLabel = new Label();
        outputField = new Label();
    }

    public void start(Stage stage) {
        // Instantiates the Service class.
        service = new CityPopulationService();

        // Using a Label to hold population because the textarea gets an unwanted scrollbar.
        // Set the Font to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Retrieve the formatted population data by calling the getTable method in the service class with NAME sequence.
        // Center the label.
        tableData.setFont(Font.font("MONOSPACED", FontWeight.EXTRA_BOLD, 24));
        tableData.setText(service.getTable(SEQUENCE.NAME));
        tableData.setAlignment(Pos.CENTER);

        // Create a button by calling a createButton method with a parameter of the button text.
        Button sortAscButton    = createButton("Sort Ascending");
        Button sortDscButton    = createButton("Sort Descending");
        Button sortNameButton   = createButton("Sort Name");
        Button getTotalButton   = createButton("Get Total");
        Button getHighestButton = createButton("Get Highest");
        Button getAverageButton = createButton("Get Average");
        Button getLowestButton  = createButton("Get Lowest");

        // Call the setOnAction method on the button object with a lambda argument of the action to be taken when
        // button is clicked.
        sortAscButton.setOnAction(e ->    getTable(SEQUENCE.ASC));
        sortDscButton.setOnAction(e -> getTable(SEQUENCE.DSC));
        sortNameButton.setOnAction(e -> getTable(SEQUENCE.NAME));
        getTotalButton.setOnAction(e -> getStat(CityPopulationService.STATISTIC.TOTAL));
        getAverageButton.setOnAction(e -> getStat(CityPopulationService.STATISTIC.AVERAGE));
        getHighestButton.setOnAction(e -> getStat(CityPopulationService.STATISTIC.HIGHEST));
        getLowestButton.setOnAction(e -> getStat(CityPopulationService.STATISTIC.LOWEST));

        // Create a grid pane to collect the components into one container
        // Set the padding around the panel to 20.
        // Set the alignment to center
        // Set the gap between components to 20 (Horizontal) and 15 (Vertical).
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(10);

        // Add population date to grid pane.
        grid.add(tableData,        0, 0, 4, 1);           // Row 0, column 0, column span 4, row span 1

        // Add buttons to grid pane.
        grid.add(sortAscButton,    0, 1);                       // Row 1, column 0
        grid.add(sortDscButton, 0 , 2);
        grid.add(sortNameButton, 0, 3);
        grid.add(getTotalButton, 1, 1);
        grid.add(getAverageButton, 1, 2);
        grid.add(getHighestButton, 1, 3);
        grid.add(getLowestButton, 1, 4);


        // Add output fields to grid
        grid.add(outputField, 1, 5);

        // Set the title of the stage to Population Database
        stage.setTitle("Population Database");

        // Set the grid in the scene and the scene to the stage
        stage.setScene(new Scene(grid));

        // Show the stage
        stage.show();
    }

    private Button createButton(String text) {
        // Create a JButton wth the provided text.
        Button button = new Button(text);
        // Set the button preferred size to 175 and 25
        // Set the button font to new Font attributes SANS_SERIF, BOLD, and size of 16.
        button.setPrefSize(175, 25);
        button.setFont(Font.font("SANS_SERIF", FontWeight.EXTRA_BOLD, 16));

        // Set the button border and background to blue and the text color to white
        button.setStyle(
                "-fx-border-color: #0000ff; " +
                "-fx-background-color: #0000ff;" +
                "-fx-text-fill: white;"
        );
        // return the button object
        return button;
    }

    private void getTable(SEQUENCE seq) {
        // Fetch the population data into the tableData label.
        tableData.setText(service.getTable(seq));
    }

    private void getStat(CityPopulationService.STATISTIC stat) {
        // Set the Font on the outputLabel to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Set the horizontalAlignment to Pos.RIGHT.
        // Fetch the output label
        outputLabel.setText(service.getStat(stat));

        // Set the Font on the outputField to a new Font object with attributes MONOSPACED, BOLD, and size of 24.
        // Set the horizontalAlignment to Pos.RIGHT.
        // Fetch the output field value
        outputField.setText(service.getLabel(stat));
    }

    public static void main(String[] args) { launch(args); }
}
